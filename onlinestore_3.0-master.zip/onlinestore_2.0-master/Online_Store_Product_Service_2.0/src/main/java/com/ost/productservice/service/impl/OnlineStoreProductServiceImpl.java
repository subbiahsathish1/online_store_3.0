package com.ost.productservice.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ost.productservice.database.OnlineStoreProductRepository;
import com.ost.productservice.models.Product;
import com.ost.productservice.service.OnlineStoreProductService;

@Component("onlineStoreCatelogService")
public class OnlineStoreProductServiceImpl implements OnlineStoreProductService {

	@Autowired
	@Qualifier("onlineStoreCatelogRepository")
	OnlineStoreProductRepository onlineStoreProductRepository;

	@Override
	public List<Product> getProduct(Integer catelogRefId) {
		return onlineStoreProductRepository.findByCatelogRefId(catelogRefId);
	}

}
