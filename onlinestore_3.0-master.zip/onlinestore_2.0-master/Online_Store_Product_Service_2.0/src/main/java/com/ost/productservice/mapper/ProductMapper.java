package com.ost.productservice.mapper;

import org.mapstruct.Mapper;

import com.ost.productservice.models.Product;
import com.ost.productservice.vo.ProductView;

@Mapper
public interface ProductMapper {
	Product mapCatelogview(ProductView catelogView);
}
