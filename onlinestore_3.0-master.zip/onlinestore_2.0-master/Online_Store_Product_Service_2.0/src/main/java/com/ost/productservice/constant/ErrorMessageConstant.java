package com.ost.productservice.constant;

public class ErrorMessageConstant {
	private static final String NO_DATA_FOUND = "No Data Found on server";
	private static final String BAD_REQUEST = "Bad Request";
}
