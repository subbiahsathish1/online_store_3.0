package com.ost.productservice.api;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ost.productservice.models.Product;
import com.ost.productservice.database.OnlineStoreProductRepository;
import com.ost.productservice.service.OnlineStoreProductService;

@RestController
@RequestMapping("/product")
public class OnlineStoreProductController {
	@Autowired
	@Qualifier("onlineStoreCatelogService")
	OnlineStoreProductService onlineStoreproductService;

	@Autowired
	@Qualifier("onlineStoreCatelogRepository")
	OnlineStoreProductRepository onlineStoreCatelogRepository;

	public OnlineStoreProductController(OnlineStoreProductService onlineStoreproductService) {
		this.onlineStoreproductService = onlineStoreproductService;
	}

	@GetMapping(value = "/getProduct/{productId}", produces = "application/json")
	public List<Product> getProduct(@PathVariable("productId") Integer productId) {
		return onlineStoreproductService.getProduct(productId);
	}

}
