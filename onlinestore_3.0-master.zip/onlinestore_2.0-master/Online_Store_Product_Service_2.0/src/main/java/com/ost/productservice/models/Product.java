package com.ost.productservice.models;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.ost.productservice.dto.ProductDTO;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@ApiModel
@Entity
@Table(name = "product")
@EntityListeners(AuditingEntityListener.class)
@Data
@SqlResultSetMappings({ @SqlResultSetMapping(name = "product", classes = {
		@ConstructorResult(targetClass = ProductDTO.class, columns = {
				@ColumnResult(name = "product_id", type = Integer.class),
				@ColumnResult(name = "instock_count", type = Integer.class),
				@ColumnResult(name = "is_available", type = Boolean.class),
				@ColumnResult(name = "product_desc", type = String.class),
				@ColumnResult(name = "product_name", type = String.class),
				@ColumnResult(name = "product_price", type = Integer.class),
				@ColumnResult(name = "catelog_ref_id", type = Integer.class)

		}) }) })
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer productId;
	private String productName;
	private String productDesc;
	private Integer productPrice;
	private boolean isAvailable;
	private Integer instockCount;
	private Integer catelogRefId;

}
