package com.ost.productservice.clients;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name="${dependencies.product-service.name}")
public interface ProductServiceClient {

}
