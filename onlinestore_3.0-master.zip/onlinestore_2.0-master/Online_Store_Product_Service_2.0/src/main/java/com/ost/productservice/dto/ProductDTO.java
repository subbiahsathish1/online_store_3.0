package com.ost.productservice.dto;

import lombok.Data;

@Data
public class ProductDTO {
	private Integer productId;
	private String productName;
	private String productDesc;
	private Integer productPrice;
	private boolean isAvailable;
	private Integer instockCount;
}
