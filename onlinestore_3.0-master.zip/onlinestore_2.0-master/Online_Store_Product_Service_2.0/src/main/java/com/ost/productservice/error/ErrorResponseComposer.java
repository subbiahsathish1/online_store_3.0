package com.ost.productservice.error;

import org.springframework.stereotype.Component;

import com.ost.productservice.enums.ErrorCodeEnum;

import lombok.Data;

@Data
@Component
public class ErrorResponseComposer {
	private ErrorCodeEnum errorCode;
	private String errorMessage;
}
