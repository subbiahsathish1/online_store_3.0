package com.ost.productservice.service;

import java.util.List;

import com.ost.productservice.models.Product;

public interface OnlineStoreProductService {
	List<Product> getProduct(Integer catelogRefId);
}
