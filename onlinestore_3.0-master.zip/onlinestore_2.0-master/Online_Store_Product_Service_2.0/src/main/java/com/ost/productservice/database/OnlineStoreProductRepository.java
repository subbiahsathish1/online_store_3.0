package com.ost.productservice.database;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ost.productservice.models.Product;

@Qualifier("onlineStoreCatelogRepository")
@Repository
public interface OnlineStoreProductRepository extends JpaRepository<Product, Integer> {

	List<Product> findByCatelogRefId(Integer catelogRefId);
}
