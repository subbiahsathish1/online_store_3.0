package com.ost.productservice.vo;

import lombok.Data;

@Data
public class ProductView {
	private int catelogId;
	private String catelogName;
	private String catelogDesc;
}
